<!doctype html>
<html>
    <head>
    
        
        

        <title>Laravel</title>

       

    </head>
    <body>
      
                    Dsadsa: <?php echo e($fullname); ?>

              

       
    </body>
</html>
