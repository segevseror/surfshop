<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-md-12">
        <h1><?php echo e($title); ?></h1>

    </div>
</div><br>

<div class="container">
    <form action="" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="col-md-6">

            <div class="form-group row">
                <label for="inputname" class="col-sm-2 col-form-label">Name</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputname" placeholder="Name" name="name" value="<?php echo e(old('name')); ?>">
                </div>
            </div>

            <div class="form-group row">
                <label for="inputEmail" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputEmail" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
                </div>
            </div>

            <div class="form-group row">
                <label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" id="inputPassword" placeholder="Password" name="password">
                </div>
            </div>

            <div class="form-group row">
                <label for="inputPassword3" class="col-sm-2 col-form-label">Confirm password</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" id="inputPassword3" placeholder="Confirm password" name="password_confirmation">
                </div>
            </div>
            <input class='btn-success' type="submit" name="signup" value="SignUp">

        </div>

    </form>


    <?php $__env->stopSection(); ?>;
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>