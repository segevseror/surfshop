<!DOCTYPE html>
<html lang="en">
    <head>
        <title>
            <?php if( !empty($title) ): ?>
            <?php echo e($title); ?>

            <?php endif; ?>
        </title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link href="uikit/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="uikit/css/uikit.css" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
        <script>var BASE_URL = "<?php echo e(url('')); ?>/"</script>
        
    </head>
   

        <body class="tile-1-bg">
  
    <!-- 
    To activate preloader : (1) Uncomment this section (2) Add "no-flow" class to body
    =====================================================================================
    <div class="page-preloader">
      <div class="vcenter"> <div class="vcenter-this"><img class="anim" src="images/loader.gif" alt="loading..." /></div></div>
    </div>
    ======================================================================================
    --> 
    
    <!-- Page Wrapper
    ++++++++++++++++++++++++++++++++++++++++++++ -->
    <div class="page-wrapper boxed-wrapper shadow">

      <!-- Header Block
      ============================================== -->
      <header class="header-block line-top">
      
        <!-- Main Header
        ............................................ -->
        <div class="main-header container">
        
          <!-- Header Cols -->
          <div class="header-cols"> 
          
            <!-- Brand Col -->
            <div class="brand-col hidden-xs">
            
              <!-- vcenter -->
              <div class="vcenter">
                <!-- v-centered -->               
                <div class="vcenter-this">
                  <a href="index.html">
                    <img src="images/logo.png" alt="HELENA">
                  </a>
                </div>
                <!-- v-centered -->
              </div>
              <!-- vcenter -->

            </div>
            <!-- /Brand Col -->

            <!-- Right Col -->
            <div class="right-col">
            
              <!-- vcenter -->
              <div class="vcenter">
              
                <!-- v-centered -->
                <div class="vcenter-this">

                  <!-- Nav Side -->
                  <nav class="nav-side navbar hnav hnav-sm hnav-borderless" role="navigation">
                  
                    <!-- Dont Collapse -->
                    <div class="navbar-dont-collapse no-toggle">
                    
                      <!-- Nav Right -->
                      <ul class="nav navbar-nav navbar-right case-u active-bcolor navbar-center-xs">
                        <li class="dropdown has-panel">
                          <a aria-expanded="false" href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-left ti ti-user"></i><span class="hidden-sm">sign in</span><i class="fa fa-angle-down toggler hidden-xs"></i></a>
                          
                          <!-- Dropdown Panel -->
                          <div class="dropdown-menu dropdown-panel arrow-top dropdown-left-xs" data-keep-open="true">
                            <fieldset>
                              <form>
                                <div class="form-group">
                                  <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user"></i></div>
                                    <input class="form-control" placeholder="Email" type="email">
                                  </div>
                                </div>
                                <div class="form-group">
                                  <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-lock"></i></div>
                                    <input class="form-control" placeholder="Password" type="password">
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label class="checkbox-inline"><input value="" type="checkbox">Remember me </label>
                                </div>
                                <button class="btn btn-primary btn-block">sign in</button>
                              </form>
                            </fieldset>
                          </div>
                          <!-- /Dropdown Panel -->
                          
                        </li>
                        
                        <li class="dropdown has-panel">
                          <a aria-expanded="false" href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-left ti ti-pencil-alt"></i><span class="hidden-sm">sign up</span><i class="fa fa-angle-down toggler hidden-xs"></i></a>
                          
                          <!-- Dropdown Panel -->
                          <div class="dropdown-menu dropdown-panel arrow-top" data-keep-open="true">
                            <fieldset>
                              <form>
                                <div class="form-group">
                                  <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user"></i></div>
                                    <input class="form-control" placeholder="Email" type="email">
                                  </div>
                                </div>
                                <div class="form-group">
                                  <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-lock"></i></div>
                                    <input class="form-control" placeholder="Password" type="password">
                                  </div>
                                </div>
                                <div class="form-group">
                                  <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-lock"></i></div>
                                    <input class="form-control" placeholder="Repeat Password" type="password">
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label class="checkbox-inline"><input value="" type="checkbox">I accept the terms and conditions.</label>
                                </div>
                                
                                <button class="btn btn-primary btn-block">sign up</button>
                              </form>
                            </fieldset>
                          </div>
                          <!-- /Dropdown Panel -->
                          
                        </li>
                      </ul>
                      <!-- /Nav Right-->

                    </div>
                    <!-- /Dont Collapse -->
                    
                  </nav>
                  <!-- /Nav Side -->
                
                </div>
                <!-- /v-centered -->
              </div>
              <!-- /vcenter -->
              
            </div>
            <!-- /Right Col -->
            
            <!-- Left Col -->
            <div class="left-col">
            
              <!-- vcenter -->
              <div class="vcenter">
                
                <!-- v-centered -->               
                <div class="vcenter-this">
                  
                  <form class="header-search">
                    <div class="form-group">
                      <input class="form-control" placeholder="SEARCH" type="text">
                      <button class="btn btn-empty"><i class="fa fa-search"></i></button>
                    </div>
                  </form>

                </div>
                <!-- v-centered -->
                
              </div>
              <!-- vcenter -->
            
            </div>
            <!-- /Left Col -->
          </div>
          <!-- Header Cols -->
        
        </div>
        <!-- /Main Header
        .............................................. -->
        
        <!-- Nav Bottom
        .............................................. -->
        <nav class="nav-bottom hnav hnav-ruled white-bg boxed-section">
        
          <!-- Container -->
          <div class="container">
          
            <!-- Header-->
            <div class="navbar-header">
              <button type="button" class="navbar-toggle no-border" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <i class="fa fa-navicon"></i>
              </button>
              <a class="navbar-brand visible-xs" href="#"><img src="images/logo-xs.png" alt="H"></a>
            </div>
            <!-- /Header-->
          
            <!-- Collapse -->
            <div class="collapse navbar-collapse navbar-absolute">
            
              <!-- Navbar Center -->
              <ul class="nav navbar-nav navbar-center line-top line-pcolor case-c">
                <li class="active"><a href="index.html">home</a></li>
                <li class="dropdown dropdown-mega"><a href="#" class="dropdown-toggle" data-toggle="dropdown">pages<i class="fa fa-angle-down toggler"></i></a>
                  <!-- Mega Menu -->
                  <div class="mega-menu dropdown-menu">
                    <!-- Row -->
                    <div class="row">
                    
                      <!-- col -->
                      <div class="col-md-3">
                        <img class="featured-img hidden-xs hidden-sm" src="images/menu-pic.jpg" alt="">
                      </div>
                      <!-- /col -->
                      
                      <!-- col -->
                      <div class="col-md-3">
                        <h5>shop pages</h5>
                        <ul class="links">
                          <li><a href="category.html">category</a></li>
                          <li><a href="category2.html">category #2</a></li>
                          <li><a href="product.html">product details</a></li>
                          <li><a href="cart.html">cart</a></li>
                          <li><a href="checkout.html">checkout</a></li>
                        </ul>
                      </div>
                      <!-- /col -->
                      
                      <!-- col -->
                      <div class="col-md-3">
                        <h5>common pages</h5>
                        <ul class="links">
                          <li><a href="page.html">Typical Page</a></li>
                          <li><a href="error-404.html">404</a></li>
                          <li><a href="error-generic.html">generic error</a></li>
                          <li><a href="contact.html">contact</a></li>
                          <li><a href="faq.html">faq</a></li>
                        </ul>
                      </div>
                      <!-- /col -->
                      
                      <!-- col -->
                      <div class="col-md-3">
                        <h5>other pages</h5>
                        <ul class="links">
                          <li><a href="blog.html">blog</a></li>
                          <li><a href="blog-post.html">single post</a></li>
                          <li><a href="login.html">login</a></li>
                          <li><a href="register.html">register</a></li>
                        </ul>
                      </div>
                      <!-- /col -->
                    </div>
                    <!-- /Row -->
                  </div>
                  <!-- /Mega Menu -->
                </li>
                <li><a href="headers.html">headers</a></li>
                <li><a href="footers.html">footers</a></li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">features<i class="fa fa-angle-down toggler"></i></a>
                  <ul class="dropdown-menu">
                    <li><a href="uikit/index.html">Elements + Modules</a></li>
                    <li><a href="uikit/index.html#bxslider.demo?viewer=ajax">Sliders</a></li>
                    <li><a href="uikit/index.html#animations.demo?viewer=ajax">Animations</a></li>
                  </ul>
                </li>
              </ul>
              <!-- /Navbar Center -->
              
            </div>
            <!-- /Collapse -->
            
            <!-- Dont Collapse -->
            <div class="navbar-dont-collapse">

              <!-- Navbar btn-group -->
              <div class="navbar-btn-group btn-group navbar-right no-margin-r-xs">
              
                <!-- Btn Wrapper -->
                <div class="btn-wrapper dropdown">
                
                  <a class="btn btn-outline" data-toggle="dropdown"><i class="ti-plus"></i></a>
                  
                  <!-- Dropdown Menu -->
                  <ul class="dropdown-menu">
                    <li><a href="#">account home</a></li>
                    <li><a href="#">order history</a></li>
                     <li><a href="#">profile</a></li>
                  </ul>
                  <!-- /Dropdown Menu -->
                  
                </div>
                <!-- /Btn Wrapper -->

                <!-- Btn Wrapper -->
                <div class="btn-wrapper dropdown">
                
                  <a aria-expanded="false" class="btn btn-outline" data-toggle="dropdown"><b class="count count-scolor count-round">2</b><i class="ti ti-bag"></i></a>
                  
                    <!-- Dropdown Panel -->
                    <div class="dropdown-menu dropdown-panel dropdown-right" data-keep-open="true">
                      <section>
                        <!-- Mini Cart -->
                        <ul class="mini-cart">
                          <!-- Item -->
                          <li class="clearfix">
                            <img src="images/products/product1.jpg" alt="">
                            <div class="text">
                              <a class="title" href="#">Modern black hat</a>
                              <div class="details">2 x $40.50
                                <div class="btn-group">
                                  <a class="btn btn-primary" href="#"><i class="fa fa-pencil"></i></a>
                                  <a class="btn btn-default" href="#"><i class="fa fa-trash"></i></a>
                                </div>
                              </div>
                            </div>
                          </li>
                          <!-- /Item -->
                          
                          <!-- Item -->
                          <li class="clearfix">
                            <img src="images/products/product2.jpg" alt="">
                            <div class="text">
                              <a class="title" href="#">Sexy lace blouse</a>
                              <div class="details">1 x $95.00
                                <div class="btn-group">
                                  <a class="btn btn-primary" href="#"><i class="fa fa-pencil"></i></a>
                                  <a class="btn btn-default" href="#"><i class="fa fa-trash"></i></a>
                                </div>
                              </div>
                            </div>
                          </li>
                          <!-- /Item -->
                        </ul>
                        <!-- /Mini Cart -->
                      </section>
                      
                      <section>
                        <div class="row grid-10">
                          <div class="col-md-6">
                            <a class="btn btn-base btn-block margin-y-5" href="cart.html">view cart</a>
                          </div>
                          <div class="col-md-6">
                            <a class="btn btn-primary btn-block margin-y-5" href="checkout.html">checkout</a>
                          </div>
                        </div>
                      </section>
                    </div>
                    <!-- /Dropdown Panel -->
                  
                </div>
                <!-- /Btn Wrapper -->

              </div>
              <!-- /Navbar btn-group -->
              
              <!-- Navbar Left -->
              <ul class="nav navbar-nav navbar-left navbar-right-xs">
                <li class="dropdown has-panel">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown"><img class="img-left" alt="" src="images/flags/us.gif"><span>USD</span><i class="fa fa-angle-down toggler"></i></a>
                  <!-- Dropdown Panel -->
                  <div id="settings" class="dropdown-menu dropdown-panel" data-keep-open="true">
                    <fieldset>
                      <form>
                        <div class="form-group">
                          <label>Language</label>
                          <select class="form-control">
                            <option>English</option>
                            <option>French</option>
                            <option>German</option>
                            <option>Spanish</option>
                          </select>
                        </div>
                        
                        <div class="form-group">
                          <label>Currency</label>
                          <select class="form-control">
                            <option>US Dollar</option>
                            <option>Kenyan Shillings</option>
                            <option>TZ Shillings</option>
                            <option>British Pound</option>
                          </select>
                        </div>
                        <div class="form-group">
                          <label class="checkbox-inline"><input value="" type="checkbox">Remember settings </label>

                        </div>
                        <button class="btn btn-primary btn-block">change</button>
                      </form>
                    </fieldset>
                  </div>
                  <!-- /Dropdown Panel -->
                  
                </li>
              </ul>
              <!-- /Navbar Left -->
            </div>
            <!-- /Dont Collapse -->

          </div>
          <!-- /Container -->
          
        </nav>
        <!-- /Nav Bottom
        .............................................. -->
        
      </header>
      <!-- /Header Block
      ============================================== -->

      <!-- Intro Block
      ============================================ -->
      <div class="intro-block mgb-20">
      
        <!-- Container -->
        <div class="container">

          <!-- Slider Wrapper -->
          <div class="intro-slider">
          
            <!-- BxSlider -->
            <div class="bxslider" data-call="bxslider" data-options="{pager:false, mode:'fade'}">
            
              <!-- Slide -->
              <div class="slide">
                <img class="img-main" src="images/slides/slide1.jpg" alt=""/><!-- slider image + background -->
                <!-- Text -->
                <div class="text">
                  <div class="vcenter">
                    <div class="vcenter-this text-block">
                      <h5 class="bx-layer" data-anim="bounceInLeft" data-dur="1000" data-delay="700">from 5th March - 26 March</h5>
                      <h1 class="bx-layer" data-anim="bounceInDown" data-dur="1000" data-delay="100">fresh from the runway</h1><br/>
                      <p class="bx-layer" data-anim="bounceInRight" data-dur="1000" data-delay="500">Helena is a freelance fashion house specialisings in print designs and fabrics.</p>
                      <a class="btn btn-base bx-layer" data-anim="bounceInUp" data-dur="1000" data-delay="1000">shop now</a>
                    </div>
                  </div>
                </div>
                <!-- /Text -->
              </div>
              <!-- /Slide -->
              
              <!-- Slide -->
              <div class="slide">
                <img class="img-main" src="images/slides/slide2.jpg" alt=""/><!-- slider image + background -->
                <!-- Text -->
                <div class="text">
                  <div class="vcenter">
                    <div class="vcenter-this text-block">
                      <h5 class="bx-layer" data-anim="bounceInLeft" data-dur="1000" data-delay="700">from 5th March - 26 March</h5>
                      <h1 class="bx-layer" data-anim="bounceInDown" data-dur="1000" data-delay="100">designer clothes only</h1><br/>
                      <p class="bx-layer" data-anim="bounceInRight" data-dur="1000" data-delay="500">Neque porro quisquam est qui dolorem ipsum quia dolor sit amet consectetur veli..</p>
                      <a class="btn btn-white bx-layer" data-anim="bounceInUp" data-dur="1000" data-delay="1000">shop now</a>
                    </div>
                  </div>
                </div>
                <!-- /Text -->
              </div>
              <!-- /Slide -->
              
              <!-- Slide -->
              <div class="slide">
                <img class="img-main" src="images/slides/slide3.jpg" alt=""/><!-- slider image + background -->
                <!-- Text -->
                <div class="text">
                  <div class="vcenter">
                    <div class="vcenter-this text-block">
                      <h5 class="bx-layer" data-anim="bounceInLeft" data-dur="1000" data-delay="700">from 5th March - 26 March</h5>
                      <h1 class="bx-layer" data-anim="bounceInDown" data-dur="1000" data-delay="100">hot summer collection</h1><br/>
                      <p class="bx-layer" data-anim="bounceInRight" data-dur="1000" data-delay="500">Neque porro quisquam est qui dolorem ipsum quia dolor sit amet consectetur veli..</p>
                      <a class="btn btn-primary bx-layer" data-anim="bounceInUp" data-dur="1000" data-delay="1000">shop now</a>
                    </div>
                  </div>
                </div>
                <!-- /Text -->
              </div>
              <!-- /Slide -->
            
            </div>
            <!-- /BxSlider -->
            
          </div>
          <!-- Slider Wrapper -->

        </div>
        <!-- /Container -->
      
      </div>
      <!-- /Intro Block
      ============================================ -->
      
      <!-- Content Block
      ============================================ -->
      <div class="content-block">
      
        <!-- Container -->
        <div class="container no-pad-t">

          <!-- Product Tabs -->
          <div class="product-tabs">

            <!-- Nav tabs -->
            <ul class="nav nav-tabs nav-tabs-line-bottom line-pcolor nav-tabs-center case-u" role="tablist">
              <li class="active"><a href="#tab-latest" data-toggle="tab">latest</a></li>
              <li><a href="#tab-featured" data-toggle="tab">featured</a></li>
              <li><a href="#tab-trending" data-toggle="tab">trending</a></li>
            </ul>
            <!-- /Nav Tabs -->

            <!-- Tab panes -->
            <div class="tab-content tab-no-borders">
            
              <!-- Tab Latest -->
              <div class="tab-pane active" id="tab-latest">
              
                <!-- Row -->
                <div class="row">
                
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product1.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product1.jpg" data-gal="prettyPhoto[gallery 1]" title="Product Name"><img src="images/products/product1.jpg" alt=""></a></li>
                          <li><a href="images/products/product1.jpg" data-gal="prettyPhoto[gallery 1]" title="Product Name"><img src="images/products/product1.jpg" alt=""></a></li>
                          <li><a href="images/products/product1.jpg" data-gal="prettyPhoto[gallery 1]" title="Product Name"><img src="images/products/product1.jpg" alt=""></a></li>
                          <li><a href="images/products/product1.jpg" data-gal="prettyPhoto[gallery 1]" title="Product Name"><img src="images/products/product1.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <span class="label label-sale">sale</span>
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Grey winter jacket</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price price-old">$2350</span><span class="price">$1500</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                  
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product2.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product2.jpg" data-gal="prettyPhoto[gallery 2]" title="Product Name"><img src="images/products/product2.jpg" alt=""></a></li>
                          <li><a href="images/products/product2.jpg" data-gal="prettyPhoto[gallery 2]" title="Product Name"><img src="images/products/product2.jpg" alt=""></a></li>
                          <li><a href="images/products/product2.jpg" data-gal="prettyPhoto[gallery 2]" title="Product Name"><img src="images/products/product2.jpg" alt=""></a></li>
                          <li><a href="images/products/product2.jpg" data-gal="prettyPhoto[gallery 2]" title="Product Name"><img src="images/products/product2.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Black lase blouse</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price">$2600</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                  
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product3.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product3.jpg" data-gal="prettyPhoto[gallery 3]" title="Product Name"><img src="images/products/product3.jpg" alt=""></a></li>
                          <li><a href="images/products/product3.jpg" data-gal="prettyPhoto[gallery 3]" title="Product Name"><img src="images/products/product3.jpg" alt=""></a></li>
                          <li><a href="images/products/product3.jpg" data-gal="prettyPhoto[gallery 3]" title="Product Name"><img src="images/products/product3.jpg" alt=""></a></li>
                          <li><a href="images/products/product3.jpg" data-gal="prettyPhoto[gallery 3]" title="Product Name"><img src="images/products/product3.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <span class="label label-hot">popular</span>
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Chinese style coat</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price">$840</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                  
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product4.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product4.jpg" data-gal="prettyPhoto[gallery 4]" title="Product Name"><img src="images/products/product4.jpg" alt=""></a></li>
                          <li><a href="images/products/product4.jpg" data-gal="prettyPhoto[gallery 4]" title="Product Name"><img src="images/products/product4.jpg" alt=""></a></li>
                          <li><a href="images/products/product4.jpg" data-gal="prettyPhoto[gallery 4]" title="Product Name"><img src="images/products/product4.jpg" alt=""></a></li>
                          <li><a href="images/products/product4.jpg" data-gal="prettyPhoto[gallery 4]" title="Product Name"><img src="images/products/product4.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Long striped dress</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price">$1820</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product5.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product5.jpg" data-gal="prettyPhoto[gallery 5]" title="Product Name"><img src="images/products/product5.jpg" alt=""></a></li>
                          <li><a href="images/products/product5.jpg" data-gal="prettyPhoto[gallery 5]" title="Product Name"><img src="images/products/product5.jpg" alt=""></a></li>
                          <li><a href="images/products/product5.jpg" data-gal="prettyPhoto[gallery 5]" title="Product Name"><img src="images/products/product5.jpg" alt=""></a></li>
                          <li><a href="images/products/product5.jpg" data-gal="prettyPhoto[gallery 5]" title="Product Name"><img src="images/products/product5.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Srapless night dress</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price">$675</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                  
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product6.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product6.jpg" data-gal="prettyPhoto[gallery 6]" title="Product Name"><img src="images/products/product6.jpg" alt=""></a></li>
                          <li><a href="images/products/product6.jpg" data-gal="prettyPhoto[gallery 6]" title="Product Name"><img src="images/products/product6.jpg" alt=""></a></li>
                          <li><a href="images/products/product6.jpg" data-gal="prettyPhoto[gallery 6]" title="Product Name"><img src="images/products/product6.jpg" alt=""></a></li>
                          <li><a href="images/products/product6.jpg" data-gal="prettyPhoto[gallery 6]" title="Product Name"><img src="images/products/product6.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <span class="label label-sale">sale</span>
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Gold detailed dress</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price price-old">$1550</span><span class="price">$1220</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                  
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product7.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product7.jpg" data-gal="prettyPhoto[gallery 7]" title="Product Name"><img src="images/products/product7.jpg" alt=""></a></li>
                          <li><a href="images/products/product7.jpg" data-gal="prettyPhoto[gallery 7]" title="Product Name"><img src="images/products/product7.jpg" alt=""></a></li>
                          <li><a href="images/products/product7.jpg" data-gal="prettyPhoto[gallery 7]" title="Product Name"><img src="images/products/product7.jpg" alt=""></a></li>
                          <li><a href="images/products/product7.jpg" data-gal="prettyPhoto[gallery 7]" title="Product Name"><img src="images/products/product7.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      
                      <span class="label label-sale">sale</span>
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">One pice business suit</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price price-old">$3350</span><span class="price">$2050</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                  
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product8.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product8.jpg" data-gal="prettyPhoto[gallery 8]" title="Product Name"><img src="images/products/product8.jpg" alt=""></a></li>
                          <li><a href="images/products/product8.jpg" data-gal="prettyPhoto[gallery 8]" title="Product Name"><img src="images/products/product8.jpg" alt=""></a></li>
                          <li><a href="images/products/product8.jpg" data-gal="prettyPhoto[gallery 8]" title="Product Name"><img src="images/products/product8.jpg" alt=""></a></li>
                          <li><a href="images/products/product8.jpg" data-gal="prettyPhoto[gallery 8]" title="Product Name"><img src="images/products/product8.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Premium fur jacket</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price">$8400</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="product.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                
                </div>
                <!-- /Row -->
              
              </div>
              <!-- /Tab Latest -->
              
              <!-- Tab Featured -->
              <div class="tab-pane" id="tab-featured">
              
                <!-- Row -->
                <div class="row">
                
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product5.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product5.jpg" data-gal="prettyPhoto[gallery 5]" title="Product Name"><img src="images/products/product5.jpg" alt=""></a></li>
                          <li><a href="images/products/product5.jpg" data-gal="prettyPhoto[gallery 5]" title="Product Name"><img src="images/products/product5.jpg" alt=""></a></li>
                          <li><a href="images/products/product5.jpg" data-gal="prettyPhoto[gallery 5]" title="Product Name"><img src="images/products/product5.jpg" alt=""></a></li>
                          <li><a href="images/products/product5.jpg" data-gal="prettyPhoto[gallery 5]" title="Product Name"><img src="images/products/product5.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Srapless night dress</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price">$675</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                  
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product6.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product6.jpg" data-gal="prettyPhoto[gallery 6]" title="Product Name"><img src="images/products/product6.jpg" alt=""></a></li>
                          <li><a href="images/products/product6.jpg" data-gal="prettyPhoto[gallery 6]" title="Product Name"><img src="images/products/product6.jpg" alt=""></a></li>
                          <li><a href="images/products/product6.jpg" data-gal="prettyPhoto[gallery 6]" title="Product Name"><img src="images/products/product6.jpg" alt=""></a></li>
                          <li><a href="images/products/product6.jpg" data-gal="prettyPhoto[gallery 6]" title="Product Name"><img src="images/products/product6.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <span class="label label-sale">sale</span>
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Gold detailed dress</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price price-old">$1550</span><span class="price">$1220</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                  
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product7.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product7.jpg" data-gal="prettyPhoto[gallery 7]" title="Product Name"><img src="images/products/product7.jpg" alt=""></a></li>
                          <li><a href="images/products/product7.jpg" data-gal="prettyPhoto[gallery 7]" title="Product Name"><img src="images/products/product7.jpg" alt=""></a></li>
                          <li><a href="images/products/product7.jpg" data-gal="prettyPhoto[gallery 7]" title="Product Name"><img src="images/products/product7.jpg" alt=""></a></li>
                          <li><a href="images/products/product7.jpg" data-gal="prettyPhoto[gallery 7]" title="Product Name"><img src="images/products/product7.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      
                      <span class="label label-sale">sale</span>
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">One pice business suit</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price price-old">$3350</span><span class="price">$2050</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                  
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product8.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product8.jpg" data-gal="prettyPhoto[gallery 8]" title="Product Name"><img src="images/products/product8.jpg" alt=""></a></li>
                          <li><a href="images/products/product8.jpg" data-gal="prettyPhoto[gallery 8]" title="Product Name"><img src="images/products/product8.jpg" alt=""></a></li>
                          <li><a href="images/products/product8.jpg" data-gal="prettyPhoto[gallery 8]" title="Product Name"><img src="images/products/product8.jpg" alt=""></a></li>
                          <li><a href="images/products/product8.jpg" data-gal="prettyPhoto[gallery 8]" title="Product Name"><img src="images/products/product8.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Premium fur jacket</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price">$8400</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="product.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product1.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product1.jpg" data-gal="prettyPhoto[gallery 1]" title="Product Name"><img src="images/products/product1.jpg" alt=""></a></li>
                          <li><a href="images/products/product1.jpg" data-gal="prettyPhoto[gallery 1]" title="Product Name"><img src="images/products/product1.jpg" alt=""></a></li>
                          <li><a href="images/products/product1.jpg" data-gal="prettyPhoto[gallery 1]" title="Product Name"><img src="images/products/product1.jpg" alt=""></a></li>
                          <li><a href="images/products/product1.jpg" data-gal="prettyPhoto[gallery 1]" title="Product Name"><img src="images/products/product1.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <span class="label label-sale">sale</span>
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Grey winter jacket</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price price-old">$2350</span><span class="price">$1500</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                  
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product2.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product2.jpg" data-gal="prettyPhoto[gallery 2]" title="Product Name"><img src="images/products/product2.jpg" alt=""></a></li>
                          <li><a href="images/products/product2.jpg" data-gal="prettyPhoto[gallery 2]" title="Product Name"><img src="images/products/product2.jpg" alt=""></a></li>
                          <li><a href="images/products/product2.jpg" data-gal="prettyPhoto[gallery 2]" title="Product Name"><img src="images/products/product2.jpg" alt=""></a></li>
                          <li><a href="images/products/product2.jpg" data-gal="prettyPhoto[gallery 2]" title="Product Name"><img src="images/products/product2.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Black lase blouse</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price">$2600</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                  
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product3.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product3.jpg" data-gal="prettyPhoto[gallery 3]" title="Product Name"><img src="images/products/product3.jpg" alt=""></a></li>
                          <li><a href="images/products/product3.jpg" data-gal="prettyPhoto[gallery 3]" title="Product Name"><img src="images/products/product3.jpg" alt=""></a></li>
                          <li><a href="images/products/product3.jpg" data-gal="prettyPhoto[gallery 3]" title="Product Name"><img src="images/products/product3.jpg" alt=""></a></li>
                          <li><a href="images/products/product3.jpg" data-gal="prettyPhoto[gallery 3]" title="Product Name"><img src="images/products/product3.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <span class="label label-hot">popular</span>
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Chinese style coat</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price">$840</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                  
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product4.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product4.jpg" data-gal="prettyPhoto[gallery 4]" title="Product Name"><img src="images/products/product4.jpg" alt=""></a></li>
                          <li><a href="images/products/product4.jpg" data-gal="prettyPhoto[gallery 4]" title="Product Name"><img src="images/products/product4.jpg" alt=""></a></li>
                          <li><a href="images/products/product4.jpg" data-gal="prettyPhoto[gallery 4]" title="Product Name"><img src="images/products/product4.jpg" alt=""></a></li>
                          <li><a href="images/products/product4.jpg" data-gal="prettyPhoto[gallery 4]" title="Product Name"><img src="images/products/product4.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Long striped dress</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price">$1820</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                
                </div>
                <!-- /Row -->
              
              </div>
              <!-- /Tab Featured -->
            
              <!-- Tab Trending -->
              <div class="tab-pane" id="tab-trending">
              
                <!-- Row -->
                <div class="row">
                
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product2.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product2.jpg" data-gal="prettyPhoto[gallery 2]" title="Product Name"><img src="images/products/product2.jpg" alt=""></a></li>
                          <li><a href="images/products/product2.jpg" data-gal="prettyPhoto[gallery 2]" title="Product Name"><img src="images/products/product2.jpg" alt=""></a></li>
                          <li><a href="images/products/product2.jpg" data-gal="prettyPhoto[gallery 2]" title="Product Name"><img src="images/products/product2.jpg" alt=""></a></li>
                          <li><a href="images/products/product2.jpg" data-gal="prettyPhoto[gallery 2]" title="Product Name"><img src="images/products/product2.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Black lase blouse</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price">$2600</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                  
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product3.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product3.jpg" data-gal="prettyPhoto[gallery 3]" title="Product Name"><img src="images/products/product3.jpg" alt=""></a></li>
                          <li><a href="images/products/product3.jpg" data-gal="prettyPhoto[gallery 3]" title="Product Name"><img src="images/products/product3.jpg" alt=""></a></li>
                          <li><a href="images/products/product3.jpg" data-gal="prettyPhoto[gallery 3]" title="Product Name"><img src="images/products/product3.jpg" alt=""></a></li>
                          <li><a href="images/products/product3.jpg" data-gal="prettyPhoto[gallery 3]" title="Product Name"><img src="images/products/product3.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <span class="label label-hot">popular</span>
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Chinese style coat</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price">$840</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product4.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product4.jpg" data-gal="prettyPhoto[gallery 4]" title="Product Name"><img src="images/products/product4.jpg" alt=""></a></li>
                          <li><a href="images/products/product4.jpg" data-gal="prettyPhoto[gallery 4]" title="Product Name"><img src="images/products/product4.jpg" alt=""></a></li>
                          <li><a href="images/products/product4.jpg" data-gal="prettyPhoto[gallery 4]" title="Product Name"><img src="images/products/product4.jpg" alt=""></a></li>
                          <li><a href="images/products/product4.jpg" data-gal="prettyPhoto[gallery 4]" title="Product Name"><img src="images/products/product4.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Long striped dress</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price">$1820</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                  
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product7.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product7.jpg" data-gal="prettyPhoto[gallery 7]" title="Product Name"><img src="images/products/product7.jpg" alt=""></a></li>
                          <li><a href="images/products/product7.jpg" data-gal="prettyPhoto[gallery 7]" title="Product Name"><img src="images/products/product7.jpg" alt=""></a></li>
                          <li><a href="images/products/product7.jpg" data-gal="prettyPhoto[gallery 7]" title="Product Name"><img src="images/products/product7.jpg" alt=""></a></li>
                          <li><a href="images/products/product7.jpg" data-gal="prettyPhoto[gallery 7]" title="Product Name"><img src="images/products/product7.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      
                      <span class="label label-sale">sale</span>
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">One pice business suit</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price price-old">$3350</span><span class="price">$2050</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                  
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product8.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product8.jpg" data-gal="prettyPhoto[gallery 8]" title="Product Name"><img src="images/products/product8.jpg" alt=""></a></li>
                          <li><a href="images/products/product8.jpg" data-gal="prettyPhoto[gallery 8]" title="Product Name"><img src="images/products/product8.jpg" alt=""></a></li>
                          <li><a href="images/products/product8.jpg" data-gal="prettyPhoto[gallery 8]" title="Product Name"><img src="images/products/product8.jpg" alt=""></a></li>
                          <li><a href="images/products/product8.jpg" data-gal="prettyPhoto[gallery 8]" title="Product Name"><img src="images/products/product8.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Premium fur jacket</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price">$8400</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="product.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product1.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product1.jpg" data-gal="prettyPhoto[gallery 1]" title="Product Name"><img src="images/products/product1.jpg" alt=""></a></li>
                          <li><a href="images/products/product1.jpg" data-gal="prettyPhoto[gallery 1]" title="Product Name"><img src="images/products/product1.jpg" alt=""></a></li>
                          <li><a href="images/products/product1.jpg" data-gal="prettyPhoto[gallery 1]" title="Product Name"><img src="images/products/product1.jpg" alt=""></a></li>
                          <li><a href="images/products/product1.jpg" data-gal="prettyPhoto[gallery 1]" title="Product Name"><img src="images/products/product1.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <span class="label label-sale">sale</span>
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Grey winter jacket</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price price-old">$2350</span><span class="price">$1500</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                  
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product5.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product5.jpg" data-gal="prettyPhoto[gallery 5]" title="Product Name"><img src="images/products/product5.jpg" alt=""></a></li>
                          <li><a href="images/products/product5.jpg" data-gal="prettyPhoto[gallery 5]" title="Product Name"><img src="images/products/product5.jpg" alt=""></a></li>
                          <li><a href="images/products/product5.jpg" data-gal="prettyPhoto[gallery 5]" title="Product Name"><img src="images/products/product5.jpg" alt=""></a></li>
                          <li><a href="images/products/product5.jpg" data-gal="prettyPhoto[gallery 5]" title="Product Name"><img src="images/products/product5.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Srapless night dress</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price">$675</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                  
                  <!-- Col -->
                  <div class="col-sm-6 col-md-3">
                  
                    <!-- product -->
                    <div class="product clearfix">
                    
                      <!-- Image -->
                      <div class="image"> 
                        <a href="product.html" class="main"><img src="images/products/product6.jpg" alt=""></a>
                        <ul class="additional">
                          <li><a href="images/products/product6.jpg" data-gal="prettyPhoto[gallery 6]" title="Product Name"><img src="images/products/product6.jpg" alt=""></a></li>
                          <li><a href="images/products/product6.jpg" data-gal="prettyPhoto[gallery 6]" title="Product Name"><img src="images/products/product6.jpg" alt=""></a></li>
                          <li><a href="images/products/product6.jpg" data-gal="prettyPhoto[gallery 6]" title="Product Name"><img src="images/products/product6.jpg" alt=""></a></li>
                          <li><a href="images/products/product6.jpg" data-gal="prettyPhoto[gallery 6]" title="Product Name"><img src="images/products/product6.jpg" alt=""></a></li>
                        </ul>
                      </div>
                      <!-- Image -->
                      
                      <span class="label label-sale">sale</span>
                      
                      <!-- Details -->
                      <div class="details">
                      
                        <a class="title" href="product.html">Gold detailed dress</a>
                        
                        <!-- rating -->
                        <ul class="hlinks hlinks-rating">
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li class="active"><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                          <li><a href="#"><i class="icon fa fa-star"></i></a></li>
                        </ul>
                        <!-- /rating -->
                        
                        <p class="desc">Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.</p>
                        
                        <!-- Price Box -->
                        <div class="price-box">
                          <span class="price price-old">$1550</span><span class="price">$1220</span>
                        </div>
                        <!-- /Price Box -->
                        
                        <!-- buttons -->
                        <div class="btn-group">
                          <a class="btn btn-outline btn-base-hover" href="cart.html">add to cart</a>	
                          <a class="btn btn-outline btn-default-hover" href="product.html"><i class="icon fa fa-heart"></i></a>
                        </div> 
                        <!-- /buttons -->
                        
                      </div>
                      <!-- /Details -->
                      
                    </div>
                    <!-- /product -->
                  
                  </div>
                  <!-- /Col -->
                  

                
                </div>
                <!-- /Row -->
              
              </div>
              <!-- /Tab Trending -->
            </div>
            <!-- /Tab Panes -->
            
          </div>
          <!-- /Product Tabs -->
          
        </div>
        <!-- /Container -->
        
      </div>
      <!-- /Content Block
      ============================================ -->
      
      <!-- Content Block
      ============================================ -->
      <div class="content-block boxed-section cover-3-bg overlay-dark-m" >
      
        <!-- Container -->
        <div class="container cont-lg">
        
          <!-- Promo Text -->
          <div class="promo-text">
            <h5>from 5th March - 26 March</h5>
            <h1 class="boxed">dont miss the great summer sale</h1>
            <p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet consectetur veli.</p>
            <a class="btn btn-primary btn-borderless">shop now</a>
          </div>
          <!-- Promo Text -->
        
        </div>
        <!-- /Container -->
        
      </div>  
      <!-- /Content Block
      ============================================ -->
 
      <!-- Content Block
      ============================================ -->
      <div class="content-block" >
      
        <!-- Container -->
        <div class="container cont-md">
        
          <!-- Section Title -->
          <div class="section-title line-pcolor">
            <h2>all premium brands</h2>
            <p>Helena is a freelance fashion designer who specialises in print designs and combining fabrics. My designs have been sold all over the world.</p>
          </div>
          <!-- /Section Title -->
          
          <!-- Slider Wrapper -->
          <div class="brand-slider">
          
            <!-- BxSlider -->
            <div class="bxslider" data-call="bxslider" data-options="{pager:false, slideMargin:20}" data-breaks="[{screen:0, slides:2}, {screen:460, slides:3}, {screen:768, slides:5}]">
              
              <!-- Slide -->
              <div class="slide">
                <img class="img-main" src="images/company1.jpg" alt=""/>
              </div>
              <!-- /Slide -->

              <!-- Slide -->
              <div class="slide">
                <img class="img-main" src="images/company1.jpg" alt=""/>
              </div>
              <!-- /Slide -->
              
              <!-- Slide -->
              <div class="slide">
                <img class="img-main" src="images/company1.jpg" alt=""/>
              </div>
              <!-- /Slide -->
              
              <!-- Slide -->
              <div class="slide">
                <img class="img-main" src="images/company1.jpg" alt=""/>
              </div>
              <!-- /Slide -->
              
              <!-- Slide -->
              <div class="slide">
                <img class="img-main" src="images/company1.jpg" alt=""/>
              </div>
              <!-- /Slide -->
              
              <!-- Slide -->
              <div class="slide">
                <img class="img-main" src="images/company1.jpg" alt=""/>
              </div>
              <!-- /Slide -->
              
              <!-- Slide -->
              <div class="slide">
                <img class="img-main" src="images/company1.jpg" alt=""/>
              </div>
              <!-- /Slide -->
            </div>
            <!-- /BxSlider -->
            
          </div>
          <!-- Slider Wrapper -->
        </div>
        <!-- /Container -->
      
      </div>
      <!-- Content Block
      ============================================ -->

      <!-- Newsletter Block
      ============================================ -->
      <div class="newsletter-block boxed-section overlay-dark-m cover-2-bg">
      
        <!-- Container -->
        <div class="container">
          <form>
            <!-- Row -->
            <div class="row grid-10">
              <!-- Col -->
              <div class="col-sm-3 col-md-2">
                <span class="case-c">get newsletter</span>
              </div>
              <!-- Col -->
              
              <!-- Col -->
              <div class="col-sm-6 col-md-8">
                  <input class="form-control" type="text" placeholder="Enter your email address" />
              </div>
              <!-- Col -->
              
              <!-- Col -->
              <div class="col-sm-3 col-md-2">
                <button class="btn btn-block btn-color yellow-bg"><i class="icon-left fa fa-envelope"></i>subscribe</button>
              </div>
              <!-- /Col -->
              
            </div>
            <!-- /Row -->
          </form>
        </div>
        <!-- /Container -->
      
      </div>
      <!-- /Newsletter Block
      =================================================== -->

      <!-- Footer
      =================================================== -->
      <footer class="footer-block">
      
        <!-- Container -->
        <div class="container cont-top clearfix">
        
          <!-- Row -->
          <div class="row">
          
            <!-- Brand -->
            <div class="col-md-3 brand-col brand-center">
              <div class="vcenter">
                <a class="vcenter-this" href="#">
                  <img src="images/logo-footer.png" alt="logo"/>
                </a>
              </div>
            </div>
            <!-- /Brand -->
            
            <!-- Links -->
            <div class="col-md-9 links-col">
            
              <!-- Row -->
              <div class="row-fluid">
              
                <!-- Col -->
                <div class="col-xs-6 col-sm-6 col-md-6">
                  <h5>About us</h5>
                  <p>Helena is a freelance fashion designer who specialises in print designs and combining fabrics. My designs have been sold all over the world.</p>
                    <!-- hlinks -->
                    <ul class="hlinks hlinks-icons color-icons-borders color-icons-bg color-icons-hovered">
                      <li><a href="#"><i class="icon fa fa-facebook"></i></a></li>
                      <li><a href="#"><i class="icon fa fa-twitter"></i></a></li>
                      <li><a href="#"><i class="icon fa fa-rss"></i></a></li>
                      <li><a href="#"><i class="icon fa fa-google-plus"></i></a></li>
                      <li><a href="#"><i class="icon fa fa-instagram"></i></a></li>
                      <li><a href="#"><i class="icon fa fa-youtube"></i></a></li>
                    </ul>
                    <!-- /hlinks -->              
                </div>
                <!-- /Col -->
                
                <!-- Col -->
                <div class="col-xs-6 col-sm-3 col-md-3">
                  <h5>member</h5>
                  <ul class="vlinks">
                    <li><a href="#">Account</a></li>
                    <li><a href="#">Wishlist and Favourites</a></li>
                    <li><a href="#">Purchase History</a></li>
                    <li><a href="#">View Cart</a></li>
                  </ul>
                </div>
                <!-- /Col -->
                
                <!-- Col -->
                <div class="col-xs-6 col-sm-3 col-md-3 newsletter">
                  <h5>some gallery</h5>
                  <ul class="grid-list cols-3 cell-pad-5">
                    <li><img src="images/gal1.jpg" alt="" /></li>
                    <li><img src="images/gal2.jpg" alt="" /></li>
                    <li><img src="images/gal3.jpg" alt="" /></li>
                    <li><img src="images/gal4.jpg" alt="" /></li>
                    <li><img src="images/gal5.jpg" alt="" /></li>
                    <li><img src="images/gal6.jpg" alt="" /></li>
                  </ul>
                </div>
                <!-- /Col -->
                
             </div>
             <!-- /Row -->
             
            </div>
            <!-- /Links -->
            
          </div>
          <!-- /Row -->
          
        </div>
        <!-- /Container -->
        
        <!-- Bottom -->
        <div class="footer-bottom invert-colors bcolor-bg">
        
          <!-- Container -->
          <div class="container">
          
            <span class="copy-text">&copy; 2015 Your Corporation. Theme by <a href="#">Rahisi</a> Themes.</span>
            <!-- hlinks -->
            <ul class="hlinks pull-right">
              <li><a href="#">About</a></li>
              <li><a href="#">Login</a></li>
              <li><a href="#">Sign Up</a></li>
              <li><a href="#">Support</a></li>
            </ul>
            <!-- /hlinks -->
            
          </div>
          <!-- /Container -->
          
        </div>
        <!-- /Bottom -->
        
      </footer>
      <!-- /Footer
      =================================================== -->
      
      <!-- Promo Modal
      ============================================ -->      
      <div class="modal fade modal-promo" data-call="bs-modal" data-options="{show:true}">
        <!-- Dialog -->
        <div class="modal-dialog">
        
          <!-- Promo Image (use background image to allow scaling) -->
          <div class="promo-img bg-cover" style="background:url(images/modal-promo.jpg)"></div>
          
          <!-- Text Col -->
          <div class="text-col">
            <div class="text">
              <h5>daily exclusive deals</h5>
              
              <img src="images/modal-promo-xs.jpg" alt="" class="visible-xs mgb-20" />
              <p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet.</p>
              
              <!-- Modal Form -->
              <form class="form-inline modal-form">
                <div class="form-group">
                  <input type="email" class="form-control" id="exampleInputEmail2" placeholder="Email address"/>
                </div>
                <button type="submit" class="btn btn-base">Subscribe</button>
              </form>
              <!-- /Modal Form -->
              <p class="hidden-xs" >Follow us on social media for exclusive deals.</p>
              
              <!-- hlinks -->
              <ul class="hlinks hlinks-icons hlinks-icons-round color-icons-bg color-icons-hovered">
                <li><a href="#"><i class="icon fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="icon fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="icon fa fa-rss"></i></a></li>
                <li><a href="#"><i class="icon fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="icon fa fa-youtube"></i></a></li>
              </ul>
              <!-- /hlinks --> 
            </div>
          </div>
          <!-- /Text Col -->

          <button type="button" class="btn-close btn btn-base" data-dismiss="modal"><i class="fa fa-close"></i></button>
        </div>
        <!-- /Dialog -->
      </div>
      <!-- /Promo Modal
      ============================================ --> 
      
    </div>
    <!-- /Page Wrapper
    ++++++++++++++++++++++++++++++++++++++++++++++ -->


        
        
        
        
        
        
        
        
        
        
        
         <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
               <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
         <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
      
      
   
         
         
       <script type="text/javascript" src="<?php echo e(asset('js/script.js')); ?>"></script>
   
       
     <script src="uikit/js/jquery-latest.min.js"></script>
         <script src="uikit/js/uikit.js"></script>
        
     
    </body>
</html>
