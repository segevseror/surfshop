<!doctype html>
<html>
    <head>
    
        
        

        <title>Laravel</title>

       

    </head>
    <body>
      
        <form>
        <label for="name">your Name:</label>
        <input type="text" name="name" id="name">
        
       <label for="email">your email:</label>
        <input type="text" name="email" id="email">
    
        <input type="submit" value="send">
        </form>
        
        <?php $__env->startSection('namecars'); ?>
        
        </body>
</html>