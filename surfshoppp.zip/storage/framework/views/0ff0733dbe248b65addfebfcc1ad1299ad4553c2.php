<?php $__env->startSection('cms_content'); ?>

<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
    <h1 class="page-header">Edit Content</h1>


    <div class="row">
        <div class="col-md-12">

            <form action="<?php echo e(url('cms/content/' . $edit['id'])); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>

                <div class="col-md-6">

                    <div class="form-group row">
                        <label for="title" class="col-sm-2 col-form-label">Title:</label><br>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="title" placeholder="title" name="title" value="<?php echo e($edit['title']); ?>">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="article" class="col-sm-2 col-form-label">article:</label>
                        <div class="col-sm-12">
                            <textarea id='article' name="article" ><?php echo e($edit['article']); ?></textarea>
                         <!--   <input type="text" class="form-control origin-target" id="url" placeholder="<?php echo e(url('')); ?>/" name="url" value="<?php echo e(old('url')); ?>"> -->
                        </div>
                    </div>

                    <input class='btn btn-success' type="submit" name="signup" value="Save content">
                    <a href="<?php echo e(url('cms/content')); ?>" class="btn btn-default">Cancel</a>

                </div>

            </form>
        </div>
    </div>



    <?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>