<?php $__env->startSection('content'); ?>


<br>
<section class="mainContent clearfix">
        
            <div class="col-xs-12">
              <div class="page-header text-center">
                <h2>Featured Collection</h2>
              </div>
            </div>
    
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4 col-xs-12">
              <div class="thumbnail" onclick="location.href='<?php echo e(url('shop/' . $categorie['url'])); ?>'" data-segev='<?php echo e($categorie['url']); ?>'>
                <div class="imageWrapper">
                    <img  src="<?php echo e(asset('images/categorie/' . $categorie['image'])); ?>" alt="feature-collection-image">
               
                </div>
                <div class="caption">
                  <h4><?php echo e($categorie['title']); ?></h4>
                  <p><?php echo $categorie['article']; ?></p>
                </div>
              </div>
            </div>
   
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
                
      </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>