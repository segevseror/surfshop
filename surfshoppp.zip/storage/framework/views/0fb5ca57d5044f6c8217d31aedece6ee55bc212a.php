<?php $__env->startSection('cms_content'); ?>

<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
    <h1 class="page-header">Are you sure you want to delete this category?</h1>

    <div class="row">
        <div class="rol-md-6">
            <form action="<?php echo e(url('cms/categories/' . $id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('DELETE')); ?>

                <input type="submit" name="submit" value="Delete" class="btn btn-danger">
                <a href="<?php echo e(url('cms/category/')); ?>" class="btn btn-default">Cancel</a>
            </form>
        </div>
    </div>



    <?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>