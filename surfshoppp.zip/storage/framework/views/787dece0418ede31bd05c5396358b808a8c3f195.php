<?php $__env->startSection('cms_content'); ?>

<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
    <h1 class="page-header">Content</h1>


    <div class="row">
        <div class="col-md-12">
            <p>
                <a href="<?php echo e(url('cms/content/create')); ?>" class="btn btn-primary">+ Add new content</a>
            </p>

        </div>
    </div>
    <?php if($content): ?>
    <br>
    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Article</th>
                        <th>Updated</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($contents['title']); ?></td>
                        <td><?php echo e($contents['article']); ?></td>
                        <td><?php echo e($contents['updated_at']); ?></td>
                        <td>
                            <a href="<?php echo e(url('cms/content/' . $contents['id'] . '/edit')); ?>">
                                <span id="btn-remove-content" class="glyphicon glyphicon-pencil" aria-hidden="true" title='adit'></span>
                            </a> | 
                            <a href="<?php echo e(url('cms/content/' . $contents['id'])); ?>">
                                <span id="btn-remove-content" class="glyphicon glyphicon-trash btn-remove-menu" aria-hidden="true"></span>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>