<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <h1>about</h1>
        <p>sdadads</p>
    </div>
</div>

<?php $__env->stopSection(); ?>;
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>