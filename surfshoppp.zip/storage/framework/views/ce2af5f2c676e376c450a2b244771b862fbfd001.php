<?php $__env->startSection('cms_content'); ?>

<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
    <h1 class="page-header">Add new menu links</h1>


    <div class="row">
        <div class="col-md-12">

            <form action="<?php echo e(url('cms/menu/'.$edit['id'])); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>

                <input type="hidden" name="item_id" value="<?php echo e($edit['id']); ?>">
                <div class="col-md-6">
                    <div class="form-group row">
                        <label for="link" class="col-sm-2 col-form-label">Menu link:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control origin-field" id="link" placeholder="Link" name="link" value="<?php echo e($edit['link']); ?>">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="title" class="col-sm-2 col-form-label">Title:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="title" placeholder="title" name="title" value="<?php echo e($edit['title']); ?>">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="url" class="col-sm-2 col-form-label">Page URL:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control origin-target" id="url" placeholder="<?php echo e(url('')); ?>/" name="url" value="<?php echo e($edit['url']); ?>">
                        </div>
                    </div>

                    <input class='btn btn-success' type="submit" name="signup" value="Save menu link">
                    <a href="<?php echo e(url('cms/menu')); ?>" class="btn btn-default">Cancel</a>

                </div>

            </form>
        </div>
    </div>



    <?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>