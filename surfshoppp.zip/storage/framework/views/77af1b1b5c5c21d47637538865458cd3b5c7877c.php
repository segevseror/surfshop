<?php $__env->startSection('cms_content'); ?>

<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
    <h1 class="page-header">Products</h1>


    <div class="row">
        <div class="col-md-12">
            <p>
                <a href="<?php echo e(url('cms/product/create')); ?>" class="btn btn-primary">+ Add new product</a>
            </p>

        </div>
    </div>

    <!-- Product Tabs -->
    <div class="product-tabs">
        <br><br>
        <div><b> All products </b></div>
        <!-- Nav tabs -->
        <ul class="nav nav-tabs nav-tabs-line-bottom line-pcolor nav-tabs-center case-u" role="tablist">

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="#tab-<?php echo e($category['url']); ?>" data-toggle="tab"><?php echo e($category['title']); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <!-- /Nav Tabs -->

        <!-- Tab panes -->
        <div class="tab-content tab-no-borders">

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <!-- Tab Latest -->
            <div class="tab-pane" id="tab-<?php echo e($category['url']); ?>">

                <!-- Row -->
                <div class="row">
                    <table class="table table-condensed">
                        <thead>
                            <tr>
                                <th>Img</th>
                                <th>Name</th>
                                <th>Price</th>
                            
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                
                                 <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($category['id'] == $products['categorie_id']): ?>
                        <!-- Col -->
                        <tr>
                            <th><img width="20" height="20" src="<?php echo e(asset('images/products/' . $products['image'])); ?>"</th>
                        <th><?php echo e($products['title']); ?> </th>
                        <th><?php echo e($products['price']); ?> </th>
                            <td class="col-md-1">
                            <a href="<?php echo e(url('cms/product/' . $products['id'] . '/edit')); ?>">
                                <span id="btn-remove-content" class="glyphicon glyphicon-pencil" aria-hidden="true" title='adit'></span>
                            </a> | 
                            <a href="<?php echo e(url('cms/product/' . $products['id'])); ?>">
                                <span id="btn-remove-content" class="glyphicon glyphicon-trash btn-remove-menu" aria-hidden="true"></span>
                            </a>
                        </td>
                        </tr>
                        <!-- /Col -->
              
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            
                        </tbody>
                   
                    </table>
                </div>
                <!-- /Row -->

            </div>
            <!-- /Tab Latest -->


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <!-- /Product Tabs -->

    </div>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>